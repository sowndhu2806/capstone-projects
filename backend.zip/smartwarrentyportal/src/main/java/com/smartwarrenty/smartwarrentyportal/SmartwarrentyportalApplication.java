package com.smartwarrenty.smartwarrentyportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartwarrentyportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartwarrentyportalApplication.class, args);
	}

}
